//package _03Inheritance._02Exercise._01Person;

public class Child extends Person {
    public Child(String name, int age) {
        super(name, age);
    }
}
