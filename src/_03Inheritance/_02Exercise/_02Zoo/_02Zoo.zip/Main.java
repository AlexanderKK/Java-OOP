//package _03Inheritance._02Exercise._02Zoo;

public class Main {
    public static void main(String[] args) {
        Gorilla gorilla = new Gorilla("Harry");
        System.out.println(gorilla.getName());
    }
}
