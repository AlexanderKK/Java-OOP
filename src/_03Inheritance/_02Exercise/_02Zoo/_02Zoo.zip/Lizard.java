//package _03Inheritance._02Exercise._02Zoo;

public class Lizard extends Reptile {
    public Lizard(String name) {
        super(name);
    }
}
