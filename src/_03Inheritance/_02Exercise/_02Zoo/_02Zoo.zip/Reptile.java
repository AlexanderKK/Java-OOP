//package _03Inheritance._02Exercise._02Zoo;

public class Reptile extends Animal {
    public Reptile(String name) {
        super(name);
    }
}
