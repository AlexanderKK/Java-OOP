//package _03Inheritance._02Exercise._02Zoo;

public class Bear extends Mammal {
    public Bear(String name) {
        super(name);
    }
}
