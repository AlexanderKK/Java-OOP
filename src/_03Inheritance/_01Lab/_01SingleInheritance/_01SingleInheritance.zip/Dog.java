//package _03Inheritance._01Lab._01SingleInheritance;

public class Dog extends Animal {
    public void bark() {
        System.out.println("barking...");
    }
}
