//package _03Inheritance._01Lab._02HierarchicalInheritance;

public class Main {
    public static void main(String[] args) {
        
    }
}
