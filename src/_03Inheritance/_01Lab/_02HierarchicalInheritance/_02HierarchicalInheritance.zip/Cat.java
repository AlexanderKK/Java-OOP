//package _03Inheritance._01Lab._02HierarchicalInheritance;

public class Cat extends Animal {
    public void meow() {
        System.out.println("meowing...");
    }
}
