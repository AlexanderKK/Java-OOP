//package _03Inheritance._01Lab._02HierarchicalInheritance;

public class Animal {
    public void eat() {
        System.out.println("eating...");
    }
}
